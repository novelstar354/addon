import { world } from "@minecraft/server";

world.afterEvents.entityHitEntity.subscribe((event) => {

    const attacker = event.damagingEntity;
    const victim = event.hitEntity;

    const item = attacker
        ?.getComponent("minecraft:equippable")
        ?.getEquipment("Mainhand");

    if (!item) return;

    if (item.typeId === "star:amethyst_sword") {

        victim.dimension.spawnParticle(
            "minecraft:endrod",
            victim.location
        );

    }
});

import { world } from "@minecraft/server";

world.afterEvents.entityHitEntity.subscribe((event) => {

    const attacker = event.damagingEntity;

    const item =
        attacker
        ?.getComponent("minecraft:equippable")
        ?.getEquipment("Mainhand");

    if (!item) return;

    if (item.typeId.startsWith("star:emerald_")) {

        attacker.addEffect(
            "regeneration",
            60,
            {
                amplifier: 0
            }
        );

    }
});