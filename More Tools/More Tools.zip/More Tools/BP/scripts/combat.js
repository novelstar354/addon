import { world } from "@minecraft/server";

world.afterEvents.entityHitEntity.subscribe((event) => {
    const attacker = event.damagingEntity;
    const victim = event.hitEntity;

    const item = attacker
        ?.getComponent("minecraft:equippable")
        ?.getEquipment("Mainhand");

    if (!item) return;

    if (item.typeId === "star:obsidian_sword") {
        victim.addEffect("slowness", 100, {
            amplifier: 1
        });
    }
});